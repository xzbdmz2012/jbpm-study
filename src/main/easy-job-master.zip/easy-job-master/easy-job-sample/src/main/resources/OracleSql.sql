CREATE TABLE easy_job_node (
                               id NUMBER(20) NOT NULL,
                               node_id NUMBER(20) NOT NULL,
                               row_num NUMBER(20) NOT NULL,
                               counts NUMBER(20) NOT NULL,
                               weight NUMBER(11) NOT NULL,
                               status NUMBER(11) NOT NULL,
                               notify_cmd NUMBER(11),
                               notify_value NVARCHAR2(255),
                               create_time DATE NOT NULL,
                               update_time DATE NOT NULL,
                               PRIMARY KEY (id)
);
CREATE UNIQUE INDEX idx_job_node_id
    ON easy_job_node (node_id ASC);
COMMENT ON COLUMN easy_job_node.node_id IS '节点ID，必须唯一';
COMMENT ON COLUMN easy_job_node.row_num IS '节点序号';
COMMENT ON COLUMN easy_job_node.counts IS '执行次数';
COMMENT ON COLUMN easy_job_node.weight IS '权重';
COMMENT ON COLUMN easy_job_node.status IS '节点状态，1表示可用，0表示不可用';
COMMENT ON COLUMN easy_job_node.notify_cmd IS '通知指令';
COMMENT ON COLUMN easy_job_node.notify_value IS '通知值，一般记录id啥的';
COMMENT ON COLUMN easy_job_node.create_time IS '创建时间';
COMMENT ON COLUMN easy_job_node.update_time IS '更新时间，用于心跳更新';


CREATE TABLE easy_job_task (
                               id NUMBER(20) NOT NULL,
                               pid NUMBER(20),
                               name NVARCHAR2(255),
                               cron_expr NVARCHAR2(255),
                               status NUMBER(11) NOT NULL,
                               fail_count NUMBER(11) NOT NULL,
                               success_count NUMBER(11) NOT NULL,
                               invoke_info BLOB,
                               version NUMBER(11) NOT NULL,
                               node_id NUMBER(20),
                               first_start_time DATE,
                               next_start_time DATE,
                               update_time DATE,
                               create_time DATE,
                               PRIMARY KEY (id)
);
CREATE INDEX idx_tsk_next_stime
    ON easy_job_task (next_start_time ASC);
COMMENT ON COLUMN easy_job_task.pid IS '任务父id,用于实现依赖任务，限制性父任务再执行子任务';
COMMENT ON COLUMN easy_job_task.name IS '调度名称';
COMMENT ON COLUMN easy_job_task.cron_expr IS 'cron表达式';
COMMENT ON COLUMN easy_job_task.status IS '状态，0表示未开始,1表示待执行，2表示执行中，3表示异常中，4表示已完成，5表示已停止';
COMMENT ON COLUMN easy_job_task.fail_count IS '失败执行次数';
COMMENT ON COLUMN easy_job_task.success_count IS '成功执行次数';
COMMENT ON COLUMN easy_job_task.invoke_info IS '序列化的执行类方法信息';
COMMENT ON COLUMN easy_job_task.version IS '乐观锁标识';
COMMENT ON COLUMN easy_job_task.node_id IS '当前执行节点id';
COMMENT ON COLUMN easy_job_task.first_start_time IS '首次开始执行时间';
COMMENT ON COLUMN easy_job_task.next_start_time IS '下次开始执行时间';
COMMENT ON COLUMN easy_job_task.update_time IS '更新时间';
COMMENT ON COLUMN easy_job_task.create_time IS '创建时间';

CREATE TABLE easy_job_task_detail (
                                      id NUMBER(20) NOT NULL,
                                      pid NUMBER(20),
                                      task_id NUMBER(20) NOT NULL,
                                      node_id NUMBER(20) NOT NULL,
                                      retry_count NUMBER(11) NOT NULL,
                                      version NUMBER(11),
                                      start_time DATE,
                                      end_time DATE,
                                      status NUMBER(11) NOT NULL,
                                      error_msg NCLOB,
                                      PRIMARY KEY (id)
);
CREATE INDEX idx_tskd_task_id
    ON easy_job_task_detail (task_id ASC);
COMMENT ON COLUMN easy_job_task_detail.pid IS '所属明细父ID';
COMMENT ON COLUMN easy_job_task_detail.task_id IS '所属任务ID';
COMMENT ON COLUMN easy_job_task_detail.node_id IS '执行节点id';
COMMENT ON COLUMN easy_job_task_detail.retry_count IS '重试次数';
COMMENT ON COLUMN easy_job_task_detail.version IS '乐观锁标识';
COMMENT ON COLUMN easy_job_task_detail.start_time IS '开始时间';
COMMENT ON COLUMN easy_job_task_detail.end_time IS '结束时间';
COMMENT ON COLUMN easy_job_task_detail.status IS '状态，0表示未开始,1表示待执行，2表示执行中，3表示异常中，4表示已完成，5表示已停止';
COMMENT ON COLUMN easy_job_task_detail.error_msg IS '失败原因';

