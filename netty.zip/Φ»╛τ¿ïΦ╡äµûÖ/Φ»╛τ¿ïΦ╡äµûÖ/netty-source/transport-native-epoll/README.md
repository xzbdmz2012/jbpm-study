# Native transport for Linux

See [our wiki page](https://netty.io/wiki/native-transports.html).
