## Microbenchmark tests

See [our wiki page](https://netty.io/wiki/microbenchmarks.html).

